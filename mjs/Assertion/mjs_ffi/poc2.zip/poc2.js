let o = {
  functionfoo: ffi('int (iNt)foo(int)'),
};
