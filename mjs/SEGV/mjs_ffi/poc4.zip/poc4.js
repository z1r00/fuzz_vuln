(JSON.stringify([1, 2, 3])),(JSON.parse - 6.5 - 321e2)(JSON.stringify([1, 2, 3]));
