(JSON.stringify- 321e2)(JSON.stringify([1, 2, 3]));
